import { Link } from "react-router-dom";
import style from './stylehome.css';

function Home(){



    return(
        <div>
            <h1 align='center'>Pagina Home</h1>
            <br></br>
            <h2>O Banco da vida de 20 milhões de pessoas</h2>
            
        </div>
    )
}

export default Home;